/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.5166666666666667, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.525, 500, 1500, "User Log in"], "isController": false}, {"data": [0.5166666666666667, 500, 1500, "product order status"], "isController": false}, {"data": [1.0, 500, 1500, "product order status-0"], "isController": false}, {"data": [0.6083333333333333, 500, 1500, "product order status-1"], "isController": false}, {"data": [0.9833333333333333, 500, 1500, "User SignUP-0"], "isController": false}, {"data": [0.5666666666666667, 500, 1500, "User SignUP-1"], "isController": false}, {"data": [1.0, 500, 1500, "Categories-0"], "isController": false}, {"data": [0.9916666666666667, 500, 1500, "Search Product-0"], "isController": false}, {"data": [0.21666666666666667, 500, 1500, "Search Product-1"], "isController": false}, {"data": [0.36666666666666664, 500, 1500, "Product view-1"], "isController": false}, {"data": [0.16666666666666666, 500, 1500, "Search Product"], "isController": false}, {"data": [1.0, 500, 1500, "Product view-0"], "isController": false}, {"data": [0.625, 500, 1500, "Wiew items in my cart-2"], "isController": false}, {"data": [0.525, 500, 1500, "User SignUP"], "isController": false}, {"data": [0.9916666666666667, 500, 1500, "Wiew items in my cart-0"], "isController": false}, {"data": [0.3333333333333333, 500, 1500, "Product view"], "isController": false}, {"data": [0.2833333333333333, 500, 1500, "Wiew items in my cart"], "isController": false}, {"data": [0.65, 500, 1500, "Wiew items in my cart-1"], "isController": false}, {"data": [0.008333333333333333, 500, 1500, "Shops"], "isController": false}, {"data": [0.0, 500, 1500, "Categories"], "isController": false}, {"data": [0.025, 500, 1500, "EvalyHomePage"], "isController": false}, {"data": [0.008333333333333333, 500, 1500, "Campaign-1"], "isController": false}, {"data": [0.9916666666666667, 500, 1500, "EvalyHomePage-0"], "isController": false}, {"data": [0.058333333333333334, 500, 1500, "EvalyHomePage-1"], "isController": false}, {"data": [0.9916666666666667, 500, 1500, "Campaign-0"], "isController": false}, {"data": [1.0, 500, 1500, "Shops-0"], "isController": false}, {"data": [0.008333333333333333, 500, 1500, "Shops-1"], "isController": false}, {"data": [0.008333333333333333, 500, 1500, "Campaign"], "isController": false}, {"data": [0.5666666666666667, 500, 1500, "User Log in-1"], "isController": false}, {"data": [1.0, 500, 1500, "User Log in-0"], "isController": false}, {"data": [0.0, 500, 1500, "Categories-1"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1860, 0, 0.0, 1957.7360215053757, 72, 16771, 845.5, 5336.200000000001, 9452.199999999986, 13427.46999999999, 25.369632822303455, 2552.041180259084, 4.6561076368050625], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["User Log in", 60, 0, 0.0, 948.75, 304, 3188, 794.0, 1840.9999999999998, 1998.6499999999996, 3188.0, 1.3481328360221094, 55.209199321439804, 0.32781745719678246], "isController": false}, {"data": ["product order status", 60, 0, 0.0, 891.0833333333334, 330, 2081, 725.5, 1508.8999999999999, 1957.1499999999994, 2081.0, 1.3560547846132984, 54.13364520239117, 0.35887777991230846], "isController": false}, {"data": ["product order status-0", 60, 0, 0.0, 90.21666666666665, 72, 399, 74.0, 78.0, 356.6999999999988, 399.0, 1.3727778159104949, 0.48261720090603333, 0.1823220536756126], "isController": false}, {"data": ["product order status-1", 60, 0, 0.0, 800.7, 252, 2006, 646.5, 1345.5, 1882.0999999999995, 2006.0, 1.358326541700625, 53.74679696697003, 0.17907625305623473], "isController": false}, {"data": ["User SignUP-0", 60, 0, 0.0, 111.7, 72, 719, 74.0, 90.0, 385.9, 719.0, 1.3573739338958895, 0.46394616881207157, 0.16702062077234575], "isController": false}, {"data": ["User SignUP-1", 60, 0, 0.0, 861.4833333333333, 267, 2290, 771.0, 1562.8, 1938.7999999999995, 2290.0, 1.3399137988789387, 54.384623651711735, 0.1635636961522142], "isController": false}, {"data": ["Categories-0", 60, 0, 0.0, 98.33333333333337, 72, 403, 74.5, 93.6, 375.0, 403.0, 1.573192794777, 0.5361760599386455, 0.19204013608117673], "isController": false}, {"data": ["Search Product-0", 60, 0, 0.0, 105.78333333333335, 72, 1308, 74.0, 79.8, 365.0999999999987, 1308.0, 1.3499527516536922, 0.47722939072132475, 0.1819272262970796], "isController": false}, {"data": ["Search Product-1", 60, 0, 0.0, 1883.3499999999997, 463, 4932, 1654.0, 3263.7999999999997, 4294.749999999998, 4932.0, 1.3121924548933845, 119.51215657463094, 0.17555699835975944], "isController": false}, {"data": ["Product view-1", 60, 0, 0.0, 1323.9999999999998, 430, 3920, 1028.5, 2574.7, 2909.0499999999993, 3920.0, 1.433417745711692, 112.46967985510537, 0.2883633355630943], "isController": false}, {"data": ["Search Product", 60, 0, 0.0, 1989.3500000000001, 537, 5005, 1782.5, 3336.7999999999997, 4367.849999999998, 5005.0, 1.3100722723203564, 119.7821851323173, 0.3518260496954082], "isController": false}, {"data": ["Product view-0", 60, 0, 0.0, 90.28333333333329, 74, 385, 86.0, 93.9, 97.89999999999999, 385.0, 1.4729348226340984, 0.6199559653860317, 0.2977514729348226], "isController": false}, {"data": ["Wiew items in my cart-2", 60, 0, 0.0, 1005.4833333333333, 162, 11137, 562.5, 2016.1, 2141.8999999999996, 11137.0, 1.350651689440155, 54.85202274159782, 0.18993539382752178], "isController": false}, {"data": ["User SignUP", 60, 0, 0.0, 973.4333333333332, 341, 2776, 846.0, 1710.1999999999998, 2102.6499999999996, 2776.0, 1.3376733401703305, 54.750900142685154, 0.3278867269362822], "isController": false}, {"data": ["Wiew items in my cart-0", 60, 0, 0.0, 95.69999999999999, 72, 715, 74.0, 79.8, 370.8999999999987, 715.0, 1.44088758675344, 0.49530510794649507, 0.18011094834418], "isController": false}, {"data": ["Product view", 60, 0, 0.0, 1414.483333333334, 523, 3996, 1118.5, 2651.5, 2986.5499999999993, 3996.0, 1.4303082314238718, 112.82771378638347, 0.5768723628691983], "isController": false}, {"data": ["Wiew items in my cart", 60, 0, 0.0, 1917.5333333333338, 413, 13297, 1457.5, 3680.0, 4559.049999999999, 13297.0, 1.3342524850452535, 108.17608380217483, 0.5198893960283751], "isController": false}, {"data": ["Wiew items in my cart-1", 60, 0, 0.0, 815.9666666666667, 177, 2691, 566.0, 1620.1, 2341.549999999999, 2691.0, 1.4034759420832261, 56.30871573179575, 0.17406391078571262], "isController": false}, {"data": ["Shops", 60, 0, 0.0, 4317.683333333334, 1378, 10956, 3677.0, 7056.4, 7773.3, 10956.0, 1.409410161847267, 275.343300566994, 0.3289541295717742], "isController": false}, {"data": ["Categories", 60, 0, 0.0, 11000.183333333336, 6238, 16771, 11042.0, 13778.8, 14969.799999999997, 16771.0, 1.1225024320886028, 723.883786066237, 0.27295225155279507], "isController": false}, {"data": ["EvalyHomePage", 60, 0, 0.0, 2585.75, 1082, 5161, 2314.5, 3821.9, 4620.049999999999, 5161.0, 1.4514490299482317, 214.61596888758527, 0.32317419807441095], "isController": false}, {"data": ["Campaign-1", 60, 0, 0.0, 4206.099999999999, 1246, 10087, 3796.5, 6723.599999999999, 8447.799999999994, 10087.0, 1.2129788739512788, 239.59465894445566, 0.2001888961892247], "isController": false}, {"data": ["EvalyHomePage-0", 60, 0, 0.0, 179.98333333333332, 147, 1473, 149.0, 165.8, 199.0, 1473.0, 1.514807240778611, 0.5000047337726274, 0.16864064985230628], "isController": false}, {"data": ["EvalyHomePage-1", 60, 0, 0.0, 2405.233333333333, 929, 5006, 2125.0, 3672.7, 4218.7, 5006.0, 1.458647347692906, 215.19886795291, 0.16238847425487432], "isController": false}, {"data": ["Campaign-0", 60, 0, 0.0, 101.65, 72, 730, 74.0, 86.1, 392.49999999999994, 730.0, 1.33454925598879, 0.5134886785738116, 0.2215560288262639], "isController": false}, {"data": ["Shops-0", 60, 0, 0.0, 95.51666666666665, 72, 396, 74.0, 87.69999999999999, 371.84999999999997, 396.0, 1.521722589971848, 0.5112036825686677, 0.17832686601232595], "isController": false}, {"data": ["Shops-1", 60, 0, 0.0, 4221.9, 1301, 10882, 3567.0, 6951.099999999999, 7696.25, 10882.0, 1.4118643668964868, 275.3484575014119, 0.1640740816998847], "isController": false}, {"data": ["Campaign", 60, 0, 0.0, 4307.983333333333, 1319, 10161, 3872.0, 7103.9, 8525.599999999995, 10161.0, 1.2111914086156084, 239.70761318962212, 0.400970593281925], "isController": false}, {"data": ["User Log in-1", 60, 0, 0.0, 847.5999999999998, 228, 3115, 655.0, 1766.1, 1923.5499999999997, 3115.0, 1.350347714536493, 54.83967785767335, 0.16351866855715347], "isController": false}, {"data": ["User Log in-0", 60, 0, 0.0, 100.93333333333334, 72, 397, 74.0, 87.5, 393.4, 397.0, 1.3648150675583457, 0.465156697829944, 0.1666034018015559], "isController": false}, {"data": ["Categories-1", 60, 0, 0.0, 10901.666666666666, 6156, 16698, 10963.5, 13704.5, 14881.599999999999, 16698.0, 1.124058600921728, 724.5042323440837, 0.13611647120536552], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1860, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
